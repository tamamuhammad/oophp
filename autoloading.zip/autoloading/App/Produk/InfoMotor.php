<?php 
interface InfoMotor {
    public function getInfo();
}