<?php namespace App\Produk;
interface InfoMotor {
    public function getInfo();
}